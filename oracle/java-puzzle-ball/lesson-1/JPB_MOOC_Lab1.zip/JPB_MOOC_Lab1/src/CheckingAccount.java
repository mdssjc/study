/* Copyright © 2017 Oracle and/or its affiliates. All rights reserved. */

public class CheckingAccount {
    //Fields
    
    
    
    
    
    
    //Methods
    
    
    
    
    
    
    
}
